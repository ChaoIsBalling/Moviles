package com.example.gamelogic;

//import java.awt.Font;
//import java.awt.Graphics;

import com.example.engine.Graphics;
import com.example.engine.IFont;
import org.json.JSONObject;
import org.json.JSONException;
import org.json.JSONArray;
import java.awt.Color;
/**
 * Clase que representa un boton en la interfaz del juego
 */
public class Button {

    //Atributos del botón
    private float x;
    private float y;
    private float w;
    private float h;

    //Determina si tiene esquinas redondeadas
    private boolean isRound = false;
    //Radio del arco bordeado
    private float arcRadius;

    //Determina si el boton esta activado
    private boolean isEnable = true;

    //Determina si el boton esta visible
    private boolean isVisible = true;


    //Texto del boton
    Text text;

    String color; //Color por defecto
    Image imagen; //Imagen
    Figure figura; //Figura del botón

    /**
     * Constructora del botón que inicializa su posición, dimensiones, y si es redondeado o no
     */
    public Button(float x, float y, float w, float h, boolean isRound, float ar){
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.isRound = isRound;
        this.arcRadius = ar;
    }
    public Button(float x, float y, float w, float h){
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
    }
    //Constructora que te crea un boton a partir de un Json
    public Button(JSONObject json)
    {
        this.x = json.getInt("x");
        this.y= json.getInt("y");
        this.w= json.getInt("w");
        this.h=json.getInt("h");
        this.isRound=json.getBoolean("isRound");
        if(isRound)
            this.arcRadius=json.getInt("ar");
        this.color=json.getString("color");
    }
    /**
     * Setters de atributos del botón
     */
    //setter de los parametros de posicion texto color imagen y figura
    public void setX(float x){this.x=x;}
    public void setY(float y){this.y=y;}
    public void setText(Text text) {
        this.text = text;
    }
    //metodo que cambia el string del texto
    public void changeText(String message)
    {
        this.text.setText(message);
    }

    //setters
    public void setColor(String color){
        this.color = color;
    }
    public void setFigura(Figure fig){this.figura = fig;}
    public void setImagen(Image img){this.imagen = img;}
    public void setEnabled(boolean enabled){this.isEnable = enabled;}
    public void setVisible(boolean visible){this.isVisible = visible;}

    //getter de los parametros de tamaño y posicion
    public float getWidth(){return this.w;}
    public float getHeight(){return this.h;}
    public float getX(){return this.x;}
    public float getY(){return this.y;}
    public boolean isEnable(){return this.isEnable;}
    public  boolean isVisible(){return  this.isVisible;}
    /**
     * Comprueba si la coordenada x,y está dentro del botón
     */
    public boolean contains(float x, float y){
        return x >= this.x-this.w/2 && x <= this.x + this.w/2 &&
                y >= this.y-this.h/2 && y <= this.y + this.h/2;
    }


    /**
     * Metodo que renderiza el boton
     * @param gr
     */
    public void Render(Graphics gr) {
        if(this.isVisible){
            //Renderizamos el cuadrado que representa el botón
            gr.setColor(this.color);

            //Vemos si es redondeado o no
            if(isRound)
                gr.rellenarCuadradoRedondeado(this.x,this.y,this.w,this.h,this.arcRadius);
            else
                gr.rellenarCuadrado(this.x,this.y,this.w,this.h);

            //Renderizamos imagen si la tiene
            if(this.imagen != null){
                this.imagen.RenderCentrado((int)this.x,(int)this.y);
            }

            //Renderizamos figura centrada
            if(this.figura != null){
                this.figura.RenderCentrado(gr,this.x,this.y);
            }

            //Renderizamos texto centrado
            if(this.text != null){
                this.text.RenderCentrado(gr,this.x,this.y);
            }

        }

    }

}
